FREE RECRUITERS — 41 COUNTRY EDITIONS

41 separate PNG images, each 1024 x 1029 pixels.
Only the country name and round flag badge have been edited.
The source image has a solid background; these are not transparent/vector logos.
Names and flags follow the order requested.

۴۱ لوگوی مجزا با فرمت PNG، در ابعاد تصویر اصلی: ۱۰۲۴ × ۱۰۲۹ پیکسل.
فقط نام کشور و نشان پرچم تغییر کرده است.

01. Colombia — کلمبیا
02. Chile — شیلی
03. Paraguay — پاراگوئه
04. Argentina — آرژانتین
05. Brazil — برزیل
06. Uruguay — اروگوئه
07. Bolivia — بولیوی
08. Venezuela — ونزوئلا
09. Ecuador — اکوادور
10. Peru — پرو
11. Nigeria — نیجریه
12. South Africa — آفریقای جنوبی
13. Rwanda — رواندا
14. Liberia — لیبریا
15. Ghana — غنا
16. Burkina Faso — بورکینافاسو
17. Algeria — الجزایر
18. Angola — آنگولا
19. Morocco — مراکش
20. Egypt — مصر
21. China — چین
22. Nepal — نپال
23. Malaysia — مالزی
24. Thailand — تایلند
25. India — هند
26. Indonesia — اندونزی
27. Japan — ژاپن
28. South Korea — کرهٔ جنوبی
29. Vietnam — ویتنام
30. Pakistan — پاکستان
31. Philippines — فیلیپین
32. Finland — فنلاند
33. Germany — آلمان
34. Austria — اتریش
35. Hungary — مجارستان
36. France — فرانسه
37. Italy — ایتالیا
38. Denmark — دانمارک
39. Netherlands — هلند
40. Greece — یونان
41. Poland — لهستان